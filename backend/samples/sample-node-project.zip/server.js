const express = require('express');
const cors = require('cors');
const axios = require('axios'); // Missing from package.json!

const app = express();
app.use(cors());
app.use(express.json());

// Insecure AWS access key hardcoded!
const AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPL";

// References undefined environment variable in .env.example
const dbConnection = process.env.DATABASE_URL;

app.get('/api/products', async (req, res) => {
  res.json([{ id: 1, name: 'Cloud Server', price: 99.99 }]);
});

// Hardcoded port without process.env.PORT fallback and bound to 127.0.0.1
app.listen(5000, '127.0.0.1', () => {
  console.log('Server started on port 5000');
});
