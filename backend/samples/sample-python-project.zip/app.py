import os
from flask import Flask, jsonify
import requests # Missing from requirements.txt!

app = Flask(__name__)

# Hardcoded debug mode in production code
DEBUG = True

# Hardcoded DB credentials in source
MONGO_URI = "mongodb://dbadmin:SuperSecretPass123!@cluster0.example.com/mydb"

@app.route('/')
def index():
    return jsonify({"status": "running", "service": "orders-api"})

if __name__ == '__main__':
    # Bound to loopback interface 127.0.0.1
    app.run(host='127.0.0.1', port=8000, debug=DEBUG)
